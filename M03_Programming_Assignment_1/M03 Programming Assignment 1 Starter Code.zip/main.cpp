


strings for the menu
"Choose the task you want to do on your computer from the following list:"
"1. Android Studio"
"2. Visual Studio Code"
"3. Gaming" 
"4. Web Browsing with Chrome"
"5. Multiple Programming Tasks (both Android Studio and Visual Studio Code)"
"6. Zoom"
"7. Email"
"8. Create and edit documents"
"9. Everything listed above"