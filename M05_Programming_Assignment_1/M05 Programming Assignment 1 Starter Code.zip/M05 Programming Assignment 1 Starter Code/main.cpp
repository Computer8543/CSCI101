

using namespace std;



int main()
{
	output
    don't forget to format to 3 decimal places
	cout << "Acceleration is " << << " m/s^2" << endl;
    cout << setw(15) << "Time in s" << setw(15) << "Speed in m/s" << endl;
    cout << setw(30) << setfill('*') << "*" << endl;
    cout << setfill(' ');
    
   
    
    return 0;
}

