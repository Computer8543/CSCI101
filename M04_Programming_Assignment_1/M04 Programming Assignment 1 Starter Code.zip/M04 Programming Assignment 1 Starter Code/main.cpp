table heading

cout << "IvyGames Tournament Results:" << endl;
	cout << setw(35) << setfill('-') << "-" << endl;
	cout << setfill(' ');
	cout << "| " << setw(15) << left << "Username" << "| " << setw(15) << "Score" << "|"<< endl; 
	cout << setw(35) << setfill('-') << "-" << endl;
	cout << setfill(' ');