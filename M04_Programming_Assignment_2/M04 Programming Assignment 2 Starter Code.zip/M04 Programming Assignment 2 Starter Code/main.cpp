cout << "Welcome to the binary number converter 2.0." << endl; 
cout << "You will enter a binary number 1 digit at a time starting at the right and the program will convert the number to decimal." << endl;
    